package com.politecnicomalaga.strategy;

public class AlRincon implements SelectorDeseoInterface {
    @Override
    public String elegirDeseo(String deseo) {
        return "se va a un rincón a llorar";
    }
}
