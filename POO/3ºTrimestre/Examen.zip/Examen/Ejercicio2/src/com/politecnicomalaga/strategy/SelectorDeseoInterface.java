package com.politecnicomalaga.strategy;

import com.politecnicomalaga.modelo.Niño;

public interface SelectorDeseoInterface {

    int DESEO_INTENTAR_COGER = 1;
    int DESEO_DECIR_A_UN_ADULTO = 2;
    int DESEO_PONER_CARA_DE_PENA = 3;
    int DESEO_LLORAR_Y_GRITAR = 4;

    String elegirDeseo (String deseo);
}
