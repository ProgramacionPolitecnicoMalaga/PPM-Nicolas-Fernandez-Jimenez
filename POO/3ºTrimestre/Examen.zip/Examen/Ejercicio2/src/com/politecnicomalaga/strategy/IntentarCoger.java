package com.politecnicomalaga.strategy;

import com.politecnicomalaga.modelo.Niño;

public class IntentarCoger implements SelectorDeseoInterface {

    @Override
    public String elegirDeseo(String deseo) {
        return "intenta coger " + deseo + " sin que le vean";
    }
}
