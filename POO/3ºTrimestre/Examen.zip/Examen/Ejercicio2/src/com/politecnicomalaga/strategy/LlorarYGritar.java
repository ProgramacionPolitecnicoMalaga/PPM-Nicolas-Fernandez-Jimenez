package com.politecnicomalaga.strategy;

public class LlorarYGritar implements SelectorDeseoInterface {
    @Override
    public String elegirDeseo(String deseo) {
        return "llora y grita a un adulto ¡" + deseo + "!";
    }
}
