package com.politecnicomalaga.strategy;

import com.politecnicomalaga.modelo.Niño;

public class DecirAUnAdulto implements SelectorDeseoInterface {
    @Override
    public String elegirDeseo(String deseo) {
        return "dice a un adulto: ¡Quiero " + deseo + "!";
    }
}
