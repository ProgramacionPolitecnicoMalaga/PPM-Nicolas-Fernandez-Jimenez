package com.politecnicomalaga.factory;

import com.politecnicomalaga.strategy.*;

public class SelectorDeseo {

    public static SelectorDeseoInterface getSelectorDeseo(int deseo) {
        switch (deseo) {
            case SelectorDeseoInterface.DESEO_INTENTAR_COGER:
                return new IntentarCoger();
            case SelectorDeseoInterface.DESEO_DECIR_A_UN_ADULTO:
                return new DecirAUnAdulto();
            case SelectorDeseoInterface.DESEO_PONER_CARA_DE_PENA:
                return new PonerCaraDePena();
            case SelectorDeseoInterface.DESEO_LLORAR_Y_GRITAR:
                 return new LlorarYGritar();
            default:
                 return new AlRincon();
        }
    }
}
