package com.politecnicomalaga;

import com.politecnicomalaga.factory.SelectorDeseo;
import com.politecnicomalaga.modelo.Niño;
import com.politecnicomalaga.strategy.SelectorDeseoInterface;

import java.util.Scanner;

public class App {
    private static Scanner lectorTeclado = new Scanner(System.in).useDelimiter("\n");

    public static void main(String[] args) {
        Niño niño = new Niño("Jacinto García");
        niño.setDeseo("un paquete de galletas");

        int deseo = 0;

        System.out.print("Elegir opción:");
        System.out.println("1. Deseo intentar coger algo" +
                "2. Deseo pedir algo a un adulto" +
                "3. Deseo poner cara de pena" +
                "4. Deseo llorar y gritar");
        int opcion = lectorTeclado.nextInt();
    }
}
